#!/bin/bash

# Function to extract domain names with specific domain suffix from a file
extract_domains_with_specific_suffix() {
    local file="$1"
    local specific_domain="$2"
    # Use grep with regular expressions to extract domain names with specific suffix
    # Adjust the regular expression according to the format of the output
    grep -E -o "([a-zA-Z0-9]+://)?(www\.)?([^.]+\.)?$specific_domain\b" "$file"
}

# Check if an argument is provided
if [ $# -eq 0 ]; then
    echo "Usage: $0 <directory>"
    exit 1
fi

# Get the directory path from the argument
directory="$1"

# Check if the specified directory exists
if [ ! -d "$directory" ]; then
    echo "Directory '$directory' not found."
    exit 1
fi

# Read domains from domains.txt file into an array
mapfile -t specific_domains < "domains.txt"

# Iterate over all .txt files in the specified directory
for file in "$directory"/*.txt; do
    # Check if the file exists and is readable
    if [ -f "$file" ] && [ -r "$file" ]; then
        # Iterate over each specific domain suffix
        for domain in "${specific_domains[@]}"; do
            # echo Extracting domains with suffix $domain from $file...
            # Extract domain names with specific domain suffix from the file
            extracted_domains=$(extract_domains_with_specific_suffix "$file" "$domain")
            # Output extracted domains
            echo "$extracted_domains"
        done
    fi
done | sort -u
